<section class="jb-circular ptb-80">
    <div class="jb-circular-text center">
        <h4 class="pb-25 f-22">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sequi, amet!</h4>
        <p class="">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
    </div>
    <div class="jobs-show center screen-center">
        <div class="recent-job-item">
            <div class="company-info pb-10">
              <div class="logo">
                <a href="#"><img src="assets/img/job-logo/1.webp" width="75" height="75" alt="Image-HasTech"></a>
              </div>
              <div class="content">
                <h4 class="name pb-20">Darkento Ltd.</h4>
                <p class="address">New York, USA</p>
              </div>
            </div>
            <div class="main-content">
              <h3 class="title pb-10 black">Front-end Developer</h3>
              <h5 class="work-type pb-20 black">Full-time</h5>
              <p class="desc pb-25">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
            </div>
            <div class="recent-job-info">
              <div class="salary">
                <h4>$5000</h4>
                <p>/monthly</p>
              </div>
              <a class="salary-btn" href="find-jobs-single-page.php">Apply Now</a>
            </div>
        </div>
        <div class="recent-job-item">
            <div class="company-info pb-10">
              <div class="logo">
                <a href="#"><img src="assets/img/job-logo/1.webp" width="75" height="75" alt="Image-HasTech"></a>
              </div>
              <div class="content">
                <h4 class="name pb-20">Darkento Ltd.</h4>
                <p class="address">New York, USA</p>
              </div>
            </div>
            <div class="main-content">
              <h3 class="title pb-10 black">Front-end Developer</h3>
              <h5 class="work-type pb-20 black">Full-time</h5>
              <p class="desc pb-25">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
            </div>
            <div class="recent-job-info">
              <div class="salary">
                <h4>$5000</h4>
                <p>/monthly</p>
              </div>
              <a class="salary-btn" href="find-jobs-single-page.php">Apply Now</a>
            </div>
        </div>
        <div class="recent-job-item">
            <div class="company-info pb-10">
              <div class="logo">
                <a href="#"><img src="assets/img/job-logo/1.webp" width="75" height="75" alt="Image-HasTech"></a>
              </div>
              <div class="content">
                <h4 class="name pb-20">Darkento Ltd.</h4>
                <p class="address">New York, USA</p>
              </div>
            </div>
            <div class="main-content">
              <h3 class="title pb-10 black">Front-end Developer</h3>
              <h5 class="work-type pb-20 black">Full-time</h5>
              <p class="desc pb-25">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
            </div>
            <div class="recent-job-info">
              <div class="salary">
                <h4>$5000</h4>
                <p>/monthly</p>
              </div>
              <a class="salary-btn" href="find-jobs-single-page.php">Apply Now</a>
            </div>
        </div>
        <div class="recent-job-item">
            <div class="company-info pb-10">
              <div class="logo">
                <a href="#"><img src="assets/img/job-logo/1.webp" width="75" height="75" alt="Image-HasTech"></a>
              </div>
              <div class="content">
                <h4 class="name pb-20">Darkento Ltd.</h4>
                <p class="address">New York, USA</p>
              </div>
            </div>
            <div class="main-content">
              <h3 class="title pb-10 black">Front-end Developer</h3>
              <h5 class="work-type pb-20 black">Full-time</h5>
              <p class="desc pb-25">CSS3, HTML5, Javascript, Bootstrap, Jquery</p>
            </div>
            <div class="recent-job-info">
              <div class="salary">
                <h4>$5000</h4>
                <p>/monthly</p>
              </div>
              <a class="salary-btn" href="find-jobs-single-page.php">Apply Now</a>
            </div>
        </div>
       

    </div>
</section>