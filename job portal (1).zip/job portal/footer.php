<section class="footer ptb-80">
    <div class="wrapper-footer">
        
        <div class="f-content-text">
           
            <div class="social-media">
            <a href="#" class="social-icon">Facebook</a>
            <a href="#" class="social-icon">Twitter</a>
            <a href="#" class="social-icon">Instagram</a>
            <a href="#" class="social-icon">LinkedIn</a>
          
        </div>
    </div>
</section>